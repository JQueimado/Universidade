%agente esta(X,Y) sucede se esta na casa(X,Y)
h(esta(X, Y), r(A, S)) :- h(esta(W, Z), S), a = mover(W, Z, X, Y).
h(esta(X, Y), r(A, S)) :- h(esta(X, Y), S), a \= mover(_, _, _, _).

%agente ganhou
h(ganhou, r(A, S)) :- A = sair().
h(ganhou, r(_, S)) :- h(ganhou, S).

%agente visitada(X,Y)
h(visitada(X, Y), S) :- h(esta(X, Y), S).
h(visitada(X, Y), r(_, S)) :- h(visitada(X, Y), S).


h(segura(X, Y), S) :- h(visitada(X, Y), S).
h(segura(X, Y), r(_, S)) :- h(segura(X, Y), S).
h(segura(X, Y), S) :- obstruida(W, Z, X, Y), h(esta(W, Z), S), \+ h(brisa, S).

h(ganhou,r(sair,S)):-
    h(esta(X,Y),S),
    h(saida(X,Y)),
    r(sair,S).

h(perdeu,r(desistir,S)):-
    h(esta(A,B),S).

h(desistiu,r(A,S)):-h(desistiu,S).

h(ganhou,r(A,S)):-h(ganhou,S).

h(saida(X,Y),S):-h(brisa,S),h(esta(X,Y),S).
%query para saber a melhor ação
:- h(ganhou, S).