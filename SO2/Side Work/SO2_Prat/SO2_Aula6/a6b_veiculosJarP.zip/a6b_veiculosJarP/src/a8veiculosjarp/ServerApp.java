package a8veiculosjarp;

/**
 *
 * @author jsaias
 */
public class ServerApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // inicialize o Servidor Aqui... pode por exemplo chamar o metodo main() da classe do servidor
        // so2.VeiculosServer
    
    }
    
}
