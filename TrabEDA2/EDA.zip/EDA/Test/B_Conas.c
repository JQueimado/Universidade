
#include "../Struct/B-Tree.h"

int main()
{
	
	struct BTree *test_trie = new_BTree();
	
	return 0;

}