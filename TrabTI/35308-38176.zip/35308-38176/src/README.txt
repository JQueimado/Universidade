Instruções de Utilização

Compressor.py/Descompressor.py
	Os programas comprimir.py e descomprimir.py tem de ser executados num terminal.
	Após executar, o programa pergunta ao utilizador o nome do ficheiro que pertende comprimir ou descomprimir.
	Caso o ficheiro não se encontre no mesmo directorio que o programa o utilizador deve inserir o directorio seguido de '/' e o nome do ficheiro, na seção onde iria incerir o nome do ficheiro.

Entropia.py
	O programa deve de ser executado em terminal.
	Após a execução o utilizador deve inserir o nome do ficheiro com terminação '.pbm' e de seguida o ficheiro equivalente a comtpreção do mesmo com terminação '.best'
	De seguida o programa mostra o calculo das váreas entropias entre dos ficheiros
